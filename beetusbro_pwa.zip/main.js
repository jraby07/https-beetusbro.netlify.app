// Register service worker
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('service-worker.js');
}

// Handle notification button
document.getElementById('notify').onclick = async () => {
  if (!('Notification' in window)) {
    return alert('Notifications not supported');
  }
  let perm = await Notification.requestPermission();
  if (perm !== 'granted') return alert('Permission denied');

  // Use Service Worker to show a local notification
  let sw = await navigator.serviceWorker.ready;
  sw.showNotification('Beetus Bro', {
    body: 'This is your test reminder!',
    icon: 'icon-192.png'
  });
};